from projects.anateeg.viz_models import plot_head_models

if __name__ == "__main__":
    plot_head_models()
