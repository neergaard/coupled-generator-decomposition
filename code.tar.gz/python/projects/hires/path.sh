PROJECT=/mnt/newprojects/INN/jesper/nobackup/HiRes

HCP=$PROJECT/hcp
HCP_DATA=$HCP/data
HCP_CHARM=$HCP/charm

SLURM_LOGS=$PROJECT/slurm_logs
