from projects.mnieeg import evaluation_viz_surf

if __name__ == "__main__":
    evaluation_viz_surf.forward_plot()
