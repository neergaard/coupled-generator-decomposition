from projects.mnieeg import evaluation_viz_topo

if __name__ == "__main__":
    evaluation_viz_topo.channel_plot()
    evaluation_viz_topo.channel_optimization_plot()
