from setuptools import find_packages, setup

setup(
    name='TMMSAA',
    packages=find_packages(),
)